### Script description
    # This script uses the loop function defined in the script "WF_forward08_B_loop_basic_function.jl", in the same folder.
    # This script gives the starting parameters for the WF function and runs it as many times as the user wishes.
    # This script produces the simulation matrices for each treatments and with n replications.
    # NOTE: to run uncomment lines 91 and 94.
    # WARNING: doing the above will cause a 21 hour long process to start running.
## Author: Jerónimo Cid, for my Master thesis at Imperial College London.
    # Contact details:        |                       |
    # Author;                 Supervisor;             Co-supervisor;
    # Jerónimo Cid;           Armand Marie Leroi;     Ben Lambert
    # jernimo.cid19@ic.ac.uk; a.leroi@imperial.ac.uk; ben.c.lambert@gmail.com
## Function preparation
# Packages
    using DataFrames
    using Plots # check that packages "Plots" is installed
    using GLM
    using GR
    gr()

# Set working directory
    #cd("D:\\Music&documents\\Documentos\\UNIVERSIDAD - MSc EEC _ ImpColl\\1.COURSE MATERIALS\\3.Master Project - Summer Term\\Master_Project\\scripts\\Julia\\WF_forward05") # path for my laptop. form for windows, double backslashes
    cd("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\scripts\\Julia\\WF_forward08")
    pwd() # check the working directory

# Call the WF function and set the arguments
    include("WF_forward08_A_basic-function.jl") # call the function from the directory
    include("WF_forward08_B_loop_basic_function.jl")


## FUNCTION STARTS HERE
##
 # This function repeats the loop of the basic simulation n times for each treatment (n is the input) and outputs:
 #  A) a vector (T(n(S,G+2),1),1)
 #              that has T elements (one for each treatment),
 #                  all of wich have n elemnts (one for each replication of treatment)
 #                      all of wich are the simulation matrix of that run.

 T = (CSV.read("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\outputs\\treatments_1210.csv"))

function Treatment_f(T)

    Result = Any[]
    for i in 1:size(T,1)
        push!(Result, loop_WF(T[i,2],T[i,3],T[i,4]))
    end
    return Result
end

Result = Treatment_f(T)

Result[1][1] # Check the first element of the first element of Result is indeed a simulation

# The object "Result" above gives all the simulations in a vector of vectors of arrays.
# They must be concatenated in the same dimension to be usable in excel and R.
# The code below does that and exports the output, a simulation matrix.

## First this function splat1 has to be defined outside to be used in the actual concatenation.
    # splat1 concatenates the preamble columns (treatment and replicate numbers)
function splat1(e, t)
    super = zeros(0,length(t))
    for i in e
        #super = vcat(i',super)
        super = reduce(hcat,e)
    end
    return super
end

## splat3 concatenates each preamble with its matrix and then concatenates each matrix together
function splat3(Result)
    supermatrix = zeros(0,14)
    for i in 1:length(Result)
        k = 0
        for j in Result[i]
            # treatment preamble
                t = Array(T[i,:])
                e = repeat([t], inner = size(j,1))
                o = splat1(e, t)
                r = hcat(o',j)

                k = k + 1
            # n
            simulation = repeat([k],size(j,1))
            # hcat preamble, n, j
            concatenates = hcat(simulation,r) # (273,14)
            supermatrix = vcat(supermatrix, concatenates)
        end
    end
    return supermatrix
end

# @time Simulations = splat3(Result)
    # 76318.811019 seconds (4.80 M allocations: 184.214 GiB, 0.07% gc time)
    # 76318/60/60 = 21.2 hours
# CSV.write("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\outputs\\Simulations_10T_8G.csv",DataFrame(Simulations))
