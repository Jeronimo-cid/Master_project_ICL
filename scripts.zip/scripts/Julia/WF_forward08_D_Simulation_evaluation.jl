
## This script calculates the "deltas", the difference in real vs. simulated frequencies in a handfull of ways.
# packages
    using Statistics
    using StatsPlots
    using LaTeXStrings
    using DataFrames
    #Pkg.add("StatsPlots")

# Set working directory
    #cd("D:\\Music&documents\\Documentos\\UNIVERSIDAD - MSc EEC _ ImpColl\\1.COURSE MATERIALS\\3.Master Project - Summer Term\\Master_Project\\scripts\\Julia\\WF_forward05") # path for my laptop. form for windows, double backslashes
    cd("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\scripts\\Julia\\WF_forward06") # path for IC laptop
    pwd() # check the working directory
# Call the previous scripts
    include("WF_forward06_WF.jl")
    include("WF_forward06_loop_WF.jl")
    # include("WF_forward06_shannon.jl")

## This snippet calculates average percentage increase of frequencies in reality vs modelled
    # 1. Calculate mean freq for all n runs (mx7 = vec(243))
    # 2. Calculate simulated_increase_vec = (mx7 - x0)/x0
    # 3. Calculate real_increase_vec      = (x7  - x0)/x0
    # 4. Compare them.

  # 1. mean by rows (dims=2 means by row)
    mx7 = vec(mean(f, dims=2))

  # 2. Get simulated increase and deal with NaNs. Elementwise calculations (dots)
    simulated_increase_vec = replace!((mx7 .- x0)./x0, NaN=>0)

  # 3. same as above (= Infs) real data
    real_increase_vec = replace!(replace!((x7 .- x0)./x0, NaN=>0),Inf=>0)

  # 4.
    Simulated_avg_increase = mean(simulated_increase_vec)
    # 0.27822825680198665
    Real_avg_increase = mean(real_increase_vec)
    # 0.3377325876888034

## Plotting the change in frequencies in reality vs modelled
    # 1. Calculate final - initial frequency for real data      (x7 - x0) vec(243))
    # 2. Calculate final - initial frequency for simulated data (mx7 - x0) vec(243))
    # 3. plot them together and add a line of slope 1
    # 4. Calculate the slope of the line of best fit

  # 1.
    log_delta_f_real = log.(abs.(x7 .- x0))
    mean(log_delta_f_real)
    minimum(log_delta_f_real)
    maximum(log_delta_f_real)
  # 2.
    log_delta_f_simu = log.(abs.(mx7 .- x0))
    mean(log_delta_f_simu)
    minimum(log_delta_f_simu)
    maximum(log_delta_f_simu)
  # 3.
  font = Plots.font("Helvetica", 18)
  #pyplot(guidefont=font, xtickfont=font, ytickfont=font, legendfont=font)
gr()
plot_deltas = Plots.plot(log_delta_f_real, log_delta_f_simu, seriestype = :scatter, smooth=true, label="Best Fit", legend=:bottomright,guidefont=14, titlefont=16, xtickfont=10, ytickfont=10, legendfont=12) # x is real, y is simulated
plot!(plot_deltas,[(-15,-15);(-2,-2)], color="red", label = "y = x")
xlabel!("log(frequency increment in reality)"); ylabel!("log(frequency increment in simulation)"); title!("Test of predictive power of simulation - all values")
png(plot_deltas, "C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\figures\\plotdeltas_report")

  # 4.
    R = vec(hcat(log_delta_f_real))
    S = hcat(log_delta_f_simu)
    model = GLM.lm(S, R)
    #= slope =
    Coefficients:
    ─────────────────────────────────────────────────────────────────
    Estimate  Std. Error  t value  Pr(>|t|)  Lower 95%  Upper 95%
    ─────────────────────────────────────────────────────────────────
    x1  0.991326  0.00520483  190.463    <1e-99   0.981074    1.00158
    ─────────────────────────────────────────────────────────────────
    =#

    # label = map(string, species) # for naming the series as the species, needs to add them to xo and B_vec
## reproduce differences plot but just with positives and negatives
    delta_f_real = (x7 .- x0)
    delta_f_real_positives = delta_f_real[delta_f_real .>=0]
    delta_f_real_negatives = delta_f_real[delta_f_real .< 0]

    delta_f_simu = (mx7 .- x0)
    delta_f_simu_positives = delta_f_simu[delta_f_simu .>=0]
    delta_f_simu_negatives = delta_f_simu[delta_f_simu .< 0]

    delta_f_real_positives_mean = mean(delta_f_real_positives)
    delta_f_simu_positives_mean = mean(delta_f_simu_positives)

    delta_f_real_negatives_mean = mean(delta_f_real_negatives)
    delta_f_simu_negatives_mean = mean(delta_f_simu_negatives)

    # Table: average positives and negatives in real vs simulated table.
    table = DataFrame(series = ["delta_f_real_positives","delta_f_simu_positives","delta_f_real_negatives","delta_f_simu_negatives"],
                   Mean = [delta_f_real_positives_mean,delta_f_simu_positives_mean,delta_f_real_negatives_mean,delta_f_simu_negatives_mean],
                   Number_species = [length(delta_f_real_positives),length(delta_f_simu_positives),length(delta_f_real_negatives),length(delta_f_simu_negatives)])
    CSV.write("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\outputs\\mean_deltas_table_report.csv", table)

# plot deltas graph for pos and negs shared between real and simulated
    delta_f_real = (x7 .- x0)
    delta_f_real_positives = delta_f_real[delta_f_real .>=0]
    delta_f_real_negatives = delta_f_real[delta_f_real .< 0]

    delta_f_simu = (mx7 .- x0)
    delta_f_simu_positives = delta_f_simu[delta_f_simu .>=0]
    delta_f_simu_negatives = delta_f_simu[delta_f_simu .< 0]
    # 1. Find wich pos in simu are also pos in real

        positive_both_index = findall(x->x>0, delta_f_simu)
        # values in delta_f_simu with these indeces should match
    # 2. Find wich neg in real are also negs in simu

        negative_both_index = findall(x->x<0, delta_f_real)

    # 3. Get them in right order in same vector
        # series for positives
        positive_both_real =  log.(abs.(delta_f_real[positive_both_index]))
        log_delta_f_simu_positives = log.(abs.(delta_f_simu_positives))
        # series for negatives
        negative_both_simu =  log.(abs.(delta_f_simu[negative_both_index]))
        log_delta_f_real_negatives = log.(abs.(delta_f_real_negatives))

    # 4. Plot away
        # positives
plot_deltas_positves = Plots.plot(log_delta_f_simu_positives, positive_both_real, seriestype = :scatter, smooth=true, label="Best Fit", legend=:bottomright,guidefont=14, titlefont=16, xtickfont=10, ytickfont=10, legendfont=12) # x is real, y is simulated
plot!(plot_deltas_positves,[(-15,-15);(-2,-2)], color="red", label = "y = x")
xlabel!("log(positive increment in simulation)"); ylabel!("log(positive increment in reality)"); title!("Predictive power test - positive values")
using Plots
png(plot_deltas_positves, "C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\figures\\plot_positive_deltas_report")

        # negatives
plot_deltas_negatives = Plots.plot(negative_both_simu, log_delta_f_real_negatives, seriestype = :scatter, smooth=true, label="Best Fit", legend=:bottomright,guidefont=14, titlefont=16, xtickfont=10, ytickfont=10, legendfont=12) # x is real, y is simulated
plot!(plot_deltas_negatives,[(-15,-15);(-2,-2)], color="red", label = "y = x")
xlabel!("log(negative increment in simulation)"); ylabel!("log(negative increment in reality)"); title!("Predictive power test - negative values")
png(plot_deltas_negatives, "C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\figures\\plot_negative_deltas_report")
# models
    # positives
    R = vec(hcat(positive_both_real))
    S = hcat(log_delta_f_simu_positives)
    model = GLM.lm(S, R)
    #= model:
    Coefficients:
        ─────────────────────────────────────────────────────────────────
        Estimate  Std. Error  t value  Pr(>|t|)  Lower 95%  Upper 95%
        ─────────────────────────────────────────────────────────────────
        x1  0.987239  0.00464606  212.489    <1e-99   0.978051   0.996427
        ─────────────────────────────────────────────────────────────────
    =#
    # negatives
    R = vec(hcat(log_delta_f_real_negatives))
    S = hcat(negative_both_simu)
    model = GLM.lm(S, R)
    #=
        Coefficients: # worse
        ─────────────────────────────────────────────────────────────────
        Estimate  Std. Error  t value  Pr(>|t|)  Lower 95%  Upper 95%
        ─────────────────────────────────────────────────────────────────
        x1   1.02245   0.0102571  99.6826    <1e-99     1.0021    1.04281
        ─────────────────────────────────────────────────────────────────
    =#

## calculate iotas per species.iotas are the predicted freq - the real freq.
    # 1. Obtain matrix with 100 iotas
    # 2. Get the quantiles (by row). Use dims=2?
    # 3. Try to also get CI and average
    # 4. Table and export

  # 1. Obtain matrix with 100 deltas
      function iotas_matrix(matrix, vector)
          iotas_run = zeros(size(matrix,1),0) # initialise empty matrix of 243 rows, 0 cols
          for i in 1:size(matrix,2) # nr. of columns
              iotas_run_i = (matrix[:,i] .- vector)
              iotas_run = hcat(deltas_run, delta_run_i)
          end
          return iotas_run
      end

     iotas_array = deltas_matrix(f,x7)

      #  iotas_array[1,1] == f[1,1] - x7[1]
      #  iotas_array[7,9] == f[7,9] - x7[7]


  # 2. Get the quantiles of deltas_dataframe (by row). Use dims=2?

    iotas_quantiles = map(x->quantile(x, [0.05, 0.5, 0.95]),  eachrow(iotas_array))
    b = [(iotas_quantiles...)...]
    # reshape is column-major so transpose is need after reshape
    iotas_quantiles = Matrix((reshape(b,(3,243)))')

    #using PyPlot
    #PyPlot()
    Plots.plot(iotas_quantiles, seriestype = :scatter, title = "Deltas per species", xlabel = "Species", ylabel = "delta_frequency")

    # Plots.plot(iotas_array)



  # 3. Try to also get CI and average

    #confint(deltas_array) # needs a model, linear model by rows
  # 4. Add species names and export
    species_names = vec(data[data[:,3] .== 1982, 2])
    species_numbers = vec(1:243)
    iotas_quantiles = hcat(species_names,species_numbers,iotas_quantiles)
    CSV.write("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\outputs\\iotas_quantiles_report.csv", DataFrame(iotas_quantiles))

  # 5. Find out wich species are out of zero

    iotas_quantiles_pos = iotas_quantiles[iotas_quantiles[:,3] .> 0, :]
    #= 3 species
        "Faramea occidentalis"      77  0.00269583  0.0086602   0.0157446
        "Piper cordulatum"         162  9.5865e-5   0.00033399  0.000784615
        "Psychotria horizontalis"  185  0.00035648  0.00219648  0.00455148
    =#
    #=
        "Piper cordulatum"         162  0.00065899  0.00106524  0.00153462
        "Psychotria horizontalis"  185  0.00359585  0.00575273  0.0080346
    =#


    iotas_quantiles_neg = iotas_quantiles[iotas_quantiles[:,5] .< 0, :]
    #= 6 species
        "Acalypha diversifolia"    2  -0.00383526   -0.00235838   -0.00126963
        "Bactris coloniata"       26  -0.0005273    -0.0004398    -0.00031355
        "Cestrum megalophyllum"   45  -0.000952659  -0.000740159  -0.000502659
        "Conostegia cinnamomea"   56  -0.000718696  -0.000530571  -0.000243071
        "Hybanthus prunifolius"  106  -0.0216252    -0.0119139    -0.00262142
        "Piper aequale"          159  -0.000406064  -0.000331064  -0.000193564
    =#
    #=
        "Acalypha diversifolia"    2  -0.00347088   -0.00215838   -0.000670258
        "Bactris coloniata"       26  -0.0005148    -0.0003898    -0.0002273
        "Cestrum megalophyllum"   45  -0.000815159  -0.000602659  -0.000327659
        "Conostegia cinnamomea"   56  -0.000643071  -0.000355571  -1.8071e-5
        "Palicourea guianensis"  155  -0.00585797   -0.00345734   -0.000969841
        "Piper aequale"          159  -0.000368564  -0.000268564  -0.000106064
    =#

## Obtain simulation_matrix

    simulation_matrix = DataFrame(sum(allTimeSteps)/length(allTimeSteps)) # Df for colindex and CSV.write
    species_names = vec(data[data[:,3] .== 1982, 2])
    simulation_matrix = hcat(species_names,simulation_matrix,makeunique=true)
    ## Trying and failing to change column names, do it in excel finally.
    #col_names = ("species_name","1982","1985","1990","1995","2000","2005","2010","2015")
    #names!(simulation_matrix,[Symbol("species_name","1982","1985","1990","1995","2000","2005","2010","2015")])
    #names(simulation_matrix)

    #df2 = names!(simulation_matrix, [:x1,:x1_1,:x2,:x3,:x4,:x5,:x6,:x7,:x8],[:species_name,:y1982,:y1985,:y1990,:y1995,:y2000,:y2005,:y2010,:y2015])
    #names!(simulation_matrix, [:species_name,:1982,:1985,:1990,:1995,:2000,:2005,:2010,:2015])
    # rename columns to be x0->x7 instead of x1->x8
        CSV.write("\\\\icnas3.cc.ic.ac.uk\\jjc3818\\Desktop\\Master_Project\\outputs\\simulation_matrix.csv", DataFrame(simulation_matrix))
        CSV.write("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\figures\\, DataFrame(simulation_matrix))




        # y[:,"variable"] = map(x->chop(x, head=1), y[:,"variable"])
        # y.variable = parse.(Int, y.variable) #numeric
        df=DataFrame(iotas_array')
        cols=string.(collect(1:243))
        rename!(df, cols)
        y = stack(df)
        # y.variable = parse.(Int, y.variable)
        # y.variable = parse.(y[:,1], Int)
        y.variable = parse.(Int, string.(y.variable))
        y
        @time pl = @df y boxplot(:variable, :value) #group=:variable)
        typeof(pl)
        Plots.plot(x, y, xerr = (0.5xerr,2xerr), yerr = (0.5yerr,2yerr),marker = stroke(2, :orange))  #here yerr is the error bar
        Plots.plot(iotas_quantiles, seriestype = :scatter, xerr = (0.5xerr,2xerr), yerr = (0.5yerr,2yerr),marker = stroke(2, :orange), title = "Deltas per species", xlabel = "Species", ylabel = "delta_frequency")
                png(pl, "C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\figures\\accidental_art")

        StatsPlots.groupedboxplot(iotas_quantiles, group = b, bar_width = 0.8) #grouping the boxplot by species could be an option~
