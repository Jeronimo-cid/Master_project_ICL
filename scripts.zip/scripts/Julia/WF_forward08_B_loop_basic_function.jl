
### Script description
    # This script uses the WF function defined in the script "WF_forward08_A_basic-function", in the same folder.
    # This script gives the starting parameters for the WF function and runs it as many times as the user wishes.
## Author: Jerónimo Cid, for my Master thesis at Imperial College London.
    # Contact details:        |                       |
    # Author;                 Supervisor;             Co-supervisor;
    # Jerónimo Cid;           Armand Marie Leroi;     Ben Lambert
    # jernimo.cid19@ic.ac.uk; a.leroi@imperial.ac.uk; ben.c.lambert@gmail.com
## Function preparation
# Packages
    using DataFrames
    using Plots # check that packages "Plots" is installed
    using GLM
    using GR
    gr()

# Set working directory
    #cd("D:\\Music&documents\\Documentos\\UNIVERSIDAD - MSc EEC _ ImpColl\\1.COURSE MATERIALS\\3.Master Project - Summer Term\\Master_Project\\scripts\\Julia\\WF_forward05") # path for my laptop. form for windows, double backslashes
    cd("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\scripts\\Julia\\WF_forward08")
    pwd() # check the working directory

# Call the WF function and set the arguments
    include("WF_forward08_A_basic-function.jl") # call the function from the directory

## FUNCTION STARTS HERE
##
 # This function repeats the WF simulation n times (n is the input) and outputs:
 #  A) a vector n(S,G+2),1)
 #              that has n elemnts (one for each replication of treatment)
 #                      each n element is the simulation matrix of that run
 #                          (S,G+2), +1 for sp. names, +1 for first gen.

function loop_WF(Nt,St,Mt)
    n = 1000 # number of repetitions or replicates
    allTimeSteps = Array{Any}(undef, n, 1)  # initialise empty array of arrays to hold all frequencies for each run
    for i in 1:n # do the forward simulation n times
        # push!(allTimeSteps, WF(N,G)) # save the frequency matrix of the current run as the ith element of the frequencies array
        allTimeSteps[i] = WF(Nt,St,Mt)
    end # End of this nth run
    return allTimeSteps # Outputs A), B), C) and D)
end

allTimeSteps = loop_WF(Nt,St,Mt)

## END OF FUNCTION
