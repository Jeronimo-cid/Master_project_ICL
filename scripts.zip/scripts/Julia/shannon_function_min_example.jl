read_starting_frequencies = (CSV.read("D:\\Music&documents\\Documentos\\UNIVERSIDAD - MSc EEC _ ImpColl\\1.COURSE MATERIALS\\3.Master Project - Summer Term\\Master_Project\\data\\x0.csv"))
x0 = Matrix{Float64}(read_starting_frequencies) # convert it into a matrix


x0 = vec(x0)
function shannon(x)
    s = zeros(length(x)) # initialise empty vector needed for the partial sums of shannon
    for i in 1:length(x) # for each row of the end frequency vector i:
        if x[i]==0 # this case would create a NaN because log(0) = NaN
            push!(s,0) # Therefore we set the value to zero since those species do not add Bdv
        else
            push!(s,(-x[i]*log(x[i]))/log(length(x))) # the shannon formula
        end  # the denominator is to normalise (0 --> one species dominant, 1 --> complete evenness)
    end # End the row iterations for this run
    S=sum(s) # to complete the shannon sumatory operation
    return S
end

shannon(x0)
