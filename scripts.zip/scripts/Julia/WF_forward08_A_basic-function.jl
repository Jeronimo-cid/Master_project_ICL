### Script description
    # This script builds the function to model the BCI population using time series data.
    # This is done using a multinomial Wright-Fisher model including selection and migration.
## Author: Jerónimo Cid, for my Master thesis at Imperial College London.
    # Contact details:        |                       |
    # Author;                 Supervisor;             Co-supervisor;
    # Jerónimo Cid;           Armand M. Leroi;        Ben Lambert
    # jernimo.cid19@ic.ac.uk; a.leroi@imperial.ac.uk; ben.c.lambert@gmail.com

## Packages used
    using Distributions # Multinomial and poisson distributions
    using Random
    using CSV
    using DataFrames
    using Plots
    using GLM
    using GR
    gr()

## Working directory
    cd("C:\\Users\\Jeronimo\\OneDrive - Imperial College London\\Master_Project\\data\\")
    pwd()
## Arguments and Inputs to the function
    ## Arguments
    # N - a constant population size (total number of individual plants)
    # G - number of generations, 1 generation = 1 censusyear
    ## Other inputs
    # data = (CSV.read("D:\\Music&documents\\Documentos\\UNIVERSIDAD - MSc EEC _ ImpColl\\1.COURSE MATERIALS\\3.Master Project - Summer Term\\Master_Project\\data\\data_ForSim.csv"))
    data = (CSV.read("data_ForSim.csv"))
    # x0 and x7 - initial and final frequencies of each species
        x0 = data[data[:,3] .== 1982, [2,4]]
        sum(x0[2]) # check that it adds to 1. It's actually 0.9996101103944569
        x7 = data[data[:,3] .== 2015, [2,4]]
        sum(x7[2])
    # Β_vec - Beta coefficients vector corresponding to each species (-1:+1)
        B_vec = data[data[:,3] .== 1982, [2,5]]
        #B_vec = B_vec/4.7 # Transform Betas to be per naturalyears instead of per census year
        sum(B_vec[2])
        maximum(B_vec[2]) # 0.963735954913488
        minimum(B_vec[2]) # -0.364036034552001
    # N and G
        Ne = 83669
        N = Ne; #G = 07 # number of individual trees and number of generations (years, 2015-1982)
        Nt = 1; St = 1; Mt = 0

## FUNCTION STARTS HERE
##
function WF(Nt,St,Mt)
## Function preamble
  ## Preprocessing of Arguments
  S = size(x0,1) # how many (non-migrant) species, 243
  beta_new = St.*B_vec[2] # beta_new will be updated each time
  non_migrant_names = data[data[:,3] .== 1982, 2] # original names (243,1)
  G = 07 # number of generations (years, 2015-1982)
  # G = 271; #3100-1982 = 1118; 1118/4.125 = 271
  t = collect(1:G+1) # time vector, G is generations, defined in "call".
  x = zeros(S,G+1) # frequency matrix, row as species, column as generations
  x[:,1] = x0[2] # first column => first generation

  for i in 2:G+1 # start from 2nd generation end in T+1th generation

     X=x[:, i-1] # we define X as all frequencies in the last generation
     #size (S,1)

   ## Selection
     xx = X + beta_new.*X  # .* as elementwise multiplication
     #sizes (S,1) = (S,1) + (S,1) .* (S,1)
     #xx: selection adjusted probability of each species to be chosen this generation
     #xx = s_vec + X # alternative, more influence of selection. Result: Shannon rises, abundancies decrease, less extinctions.
     #xx = s_vec.*X  # alternative, but gives an error because the xx ends up not being a probability probably due to rounding errors and small numbers: https://github.com/JuliaStats/Distributions.jl/issues/1017

     # Correction scaling for multinomial [0:1]
     xx=xx/sum(xx)

   ## Genetic drift
     d = rand(Multinomial(Int(Nt.*N),xx)) # Multinomial random numbers (counts)
     # N: sampling times (population size) in integer
     # xx: probability of species to be chosen in this generation
     # d: drift. outputed individuals for each species, after selection (counts)
     f = d/(Nt*N) # individual counts=>frequency
     x[:,i] = f # set the current generation as the frequencies calculated
   ## Migration
     if Mt != 0 # some migration. If not don't do anything, f is added to x as in previous line
         # 1. Generate overall migrants
           mi = rand(Poisson((Mt*0.0002521865)*(Nt*N))) # overall migrants
         # 2. Define number of incoming migrant species
           ms = 2
         # 3. Allocate overall migrants to migrant Species
           pp = vec(repeat([1/ms],ms)) # vector of flat probabilities for ms
           am = (Int.(rand(Multinomial(mi,pp))))./(Nt*N) # [FREQUENCY] allocated migrants per species
         # 4. Create the matrix (vector of zeros, vcat with am) and vcat to last matrix
            a = Int.(zeros(ms,i-1)) # 2 = 1
            b = Int.(zeros(ms,G-size(a,2))) #
            mm = hcat(a,am,b) # 1 = j: mm=migrant matrix
            x = vcat(x,mm)
         # 5. update beta_new
            migrant_betas = sample(beta_new[1:243],ms)
            beta_new = append!(beta_new,migrant_betas)
     end
   ## Final touches

     #Error detection system
      if isnan(sum(x[:,i]))
            print("Error")
            println(x[:,(i-5:i)]) # 5 generations backward to see what happened
            println(n)
            println(xx)
            break # end the for loop
      end

   end # end of for i in 2:T+1

     # Create names for migrants, vcat to original names and append all names to migrant matrix
     if Mt != 0 # For cases with some migration
          migrant_names = Vector()
              for i in 1:(length(beta_new) - size(B_vec,1))
                  push!(migrant_names, "migrant_species_$(i)")
              end
          non_migrant_names = data[data[:,3] .== 1982, 2] # original names (243,1)
          all_names = vcat(non_migrant_names, migrant_names)

          simulated_matrix = hcat(all_names, x)
      else simulated_matrix = hcat(non_migrant_names, x)
          return simulated_matrix
     end

     return simulated_matrix # Species frequency matrix
 end # function WF()

   WF(Nt,St,Mt)


    # try plot
    # p = convert(Array{Float64,2}, (WF(Nt,St,G)[:,2:end]))
    # Plots.plot(p', legend=:outertopright, title = "Plot", xlabel = "Generations", ylabel = "Frequency")
