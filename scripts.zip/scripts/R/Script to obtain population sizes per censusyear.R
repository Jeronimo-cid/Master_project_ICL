

### Script description
# This script obtains the total population sizes per census year of the BCI dataset. 
## Author: Jer�nimo Cid, for my Master thesis at Imperial College London (2020).
# Contact details:        |                       |
# Author;                 Supervisor;             Co-supervisor;
# Jer�nimo Cid;           Armand Marie Leroi;     Ben Lambert
# jernimo.cid19@ic.ac.uk; a.leroi@imperial.ac.uk; ben.c.lambert@gmail.com

## Working Directory

setwd("C:/Users/Jeronimo/Desktop/Master_Project/data")
getwd()
rm(list=ls()) 
## Packages used
require(dplyr)
require(tidyr)
require(stringr) # str_detect

# Obtain the dataset matrix
reproductives_counts <- readRDS("C:/Users/Jeronimo/Desktop/Master_Project/data/Provisional_betas_freqs_22_4/reproductives_counts.rds")

table_counts_per_census_year <- reproductives_counts%>%select(-speciesYear)%>%
  group_by(reproductives_counts$censusyear) %>% summarise(nr._of_trees = sum(count))


# export table to outputs
write.csv(table_counts_per_census_year,file="C:/Users/Jeronimo/Desktop/Master_Project/outputs/table_counts_per_census_year.csv")

