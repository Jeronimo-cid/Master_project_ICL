# need to get names, x0 and betas on same DF
# 1. names and x0 and x8 from reproductives_counts (years too to extract last)
# 2. betas from beta1 whose generating script I import here
# 3. merge df with beta1
# 4. then remove rows with migrant species or spceies not present in 1982
# 5. export as excel.

setwd("C:/Users/Jeronimo/OneDrive - Imperial College London/Master_Project/data/Provisional_betas_freqs_22_4")
getwd()
rm(list=ls()) 
####
  #install.packages("dplyr")
  require(dplyr)
  require(stringr)
  require(lattice)
####
# 1.
  reproductives_counts <- readRDS("reproductives_counts.rds")
  df <- reproductives_counts%>%select(-count,-speciesYear)%>%filter(censusyear==1982|censusyear==2015)
  # species names in A->Z, and frequency for 1982 and 2015
  
# 2.
  beta<-readRDS("beta_freqinde.rds") #this has the betas
  beta<-as.data.frame(beta)
  max(beta$beta_freqinde_50) # 0.963736
  min(beta$beta_freqinde_50) # -0.8092461
  # betas, without species names. We assume the order of sel is the correct one.
  
  sel<-readRDS("estimates_selection.rds") #this has the sp names crossreferenced with betas
  sel<-as.data.frame(sel)
  # selection coefficients, we are only interested in the order of sp, bc its the same as betas
  
  
  # add species names in order of "sel" to betas, except the last one bc has 268 rows and sel 269
  beta$species<-head(sel$species,-1)
  
  # add the last row of zeros in, wich is all zeros, for some reason of the beta calculation
  species<-tail(sel$species, 1)
  last<-as.data.frame(species)
  last$beta_freqinde_2.5<-0
  last$beta_freqinde_50<-0
  last$beta_freqinde_97.5<-0
  last<-last%>%
    select(beta_freqinde_2.5,beta_freqinde_50,beta_freqinde_97.5, species) #get cols in right order for binding
  beta1<-rbind(beta,last)
  sum(beta1$bebeta_freqinde_50)
  
# 3. 
  
  df1 <- inner_join(beta1,df)
  # join by species betas and df, conserving rows in order of sel
  df1 <- df1 %>% select(species, censusyear, freq ,beta_freqinde_50)
  # improve the order
  
# 4. 
  df2 <- df1 %>% filter(str_detect(species, pattern = "_2", negate = TRUE)) %>% filter(str_detect(species, pattern = "_3", negate = TRUE))
  df3 <- df1 %>% filter(str_detect(species, pattern = "_", negate = TRUE))
  
  sp_absent_1982 <- df3 %>% filter(censusyear == 1982) %>% filter(freq == 0) %>% select(species)
  sp_absent_1982
  # 1       Cupania latifolia
  # 2          Hamelia patens
  # 3 Ternstroemia tepezapote
  # 4         Cedrela odorata
  # 5         Trema micrantha
  # 6        Cojoba rufescens
  df4 <- df3 %>% filter(species!="Cupania latifolia")%>% 
    filter(species != "Hamelia patens" )%>% 
    filter(species != "Ternstroemia tepezapote" )%>% 
    filter(species != "Cedrela odorata" )%>% 
    filter(species != "Trema micrantha" )%>% 
    filter(species != "Cojoba rufescens" )

# 5. 
  write.csv(df4,file="D:/Music&documents/Documentos/UNIVERSIDAD - MSc EEC _ ImpColl/1.COURSE MATERIALS/3.Master Project - Summer Term/Master_Project/data/data_ForSim.csv")

# Check that x0 and x8 add up close enough to 1
  x0 <- df4 %>% filter(censusyear == 1982) %>% select(freq)
  x8 <- df4 %>% filter(censusyear == 2015) %>% select(freq)
  sum(x0)
  # [0.9996101] or 1 to 3 decimal places
  # [0.9996101103944569] in julia (22/06) and 28
  sum(x8)
  # [0.9993399] or 1 to 3 decimal places
  # [0.9993399339933996] in julia (22/06)
  
# Plotting: 
  
  plots<-reproductives_counts%>%select(-count,-speciesYear)%>%group_by(species)
  xyplot(plots$freq ~ plots$censusyear,
         groups = plots$species,
         main = "Real frequencies",
         xlab = "Census year",
         ylab = "Frequency abundance")
  
# Evaluating Hill numbers
  
  #install.packages("hilldiv")
  require(hilldiv)
  hill_div(x0,3)
  Sh_x0 <- index_div(x0, index = "shannon")
  Sh_x0_norm <- Sh_x0/log(lengths(x0))
  # This gives the shannon index between 0 and 1 for x0. 0 = 1 sp dominant, 1 = evenness
  