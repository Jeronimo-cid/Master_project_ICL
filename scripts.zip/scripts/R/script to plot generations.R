
 
### Script description
# This script produces 7 plots, 1 for each generation of BCI data. 
# Each plot is real_x[i] vs. simu_x[i].
## Author: Jer�nimo Cid, for my Master thesis at Imperial College London.
# Contact details:        |                       |
# Author;                 Supervisor;             Co-supervisor;
# Jer�nimo Cid;           Armand Marie Leroi;     Ben Lambert
# jernimo.cid19@ic.ac.uk; a.leroi@imperial.ac.uk; ben.c.lambert@gmail.com

## Working Directory

setwd("//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/data/")
getwd()
rm(list=ls()) 
## Packages used
require(dplyr)
require(tidyr)
require(stringr) # str_detect

# Real data
# Obtain real frequencies in correct shape.
reproductives_counts <- readRDS("//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/data/Provisional_betas_freqs_22_4/reproductives_counts.rds")
real_frequencies <-as.data.frame(reproductives_counts%>%select(-count,-speciesYear)) #select useful cols
real_matrix_269 <- real_frequencies %>% spread(key = censusyear, value = freq) # spread to be usable
real_matrix_249 <- real_matrix_269 %>% filter(str_detect(species, pattern = "_", negate = TRUE)) # filter out migrants
real_matrix_243 <- real_matrix_249 %>% filter(species!="Cupania latifolia")%>% # filter out other sp. with initial freq = 0
  filter(species != "Hamelia patens" )%>% 
  filter(species != "Ternstroemia tepezapote" )%>% 
  filter(species != "Cedrela odorata" )%>% 
  filter(species != "Trema micrantha" )%>% 
  filter(species != "Cojoba rufescens" )

# Simulated data
# Read the simulated frequencies from julia, get the real data in shape.

simulation_matrix_243 <- read.csv("//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/outputs/simulation_matrix.csv")

# Obtain slopes and R2 for each generation of real vs. simulated

###
#linear models
###

lm_x1 <- lm(real_matrix_243$"1985" ~ simulation_matrix$simu_x1)
summary(lm_x1)
# slope: 1.013e+00, std. err: 2.780e-03, R2: 0.9982
###
lm_x2 <- lm(real_matrix_243$"1990" ~ simulation_matrix$simu_x2)
summary(lm_x2)
# slope: 1.025e+00, std. err: 2.504e-03, R2: 0.9986
###
lm_x3 <- lm(real_matrix_243$"1995" ~ simulation_matrix$simu_x3)
summary(lm_x3)
# slope: 1.022e+00, std. err: 2.297e-03, R2: 0.9988
###
lm_x4 <- lm(real_matrix_243$"2000" ~ simulation_matrix$simu_x4)
summary(lm_x4)
# slope: 1.007e+00, std. err: 2.117e-03, R2: 0.9989
###
lm_x5 <- lm(real_matrix_243$"2005" ~ simulation_matrix$simu_x5)
summary(lm_x5)
# slope: 1.004e+00, std. err: 1.521e-03, R2: 0.9994
###
lm_x6 <- lm(real_matrix_243$"2010" ~ simulation_matrix$simu_x6)
summary(lm_x6)
# slope: 9.912e-01, std. err: 1.162e-03, R2: 0.9997
###
lm_x7 <- lm(real_matrix_243$"2015" ~ simulation_matrix$simu_x7)
summary(lm_x7)
# slope: 9.931e-01, std. err: 1.211e-03, R2: 0.9996


###
#plots
###

pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot1.pdf",plot1)
plot1<-plot(log(real_matrix_243$"1985") ~ log(simulation_matrix$simu_x1),main="G1")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot2.pdf",plot1)
plot2<-plot(log(real_matrix_243$"1990") ~ log(simulation_matrix$simu_x2),main="G2")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot3.pdf",plot1)
plot3<-plot(log(real_matrix_243$"1995") ~ log(simulation_matrix$simu_x3),main="G3")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot4.pdf",plot1)
plot4<-plot(log(real_matrix_243$"2000") ~ log(simulation_matrix$simu_x4),main="G4")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot5.pdf",plot1)
plot5<-plot(log(real_matrix_243$"2005") ~ log(simulation_matrix$simu_x5),main="G5")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot6.pdf",plot1)
plot6<-plot(log(real_matrix_243$"2010") ~ log(simulation_matrix$simu_x6),main="G6")
dev.off()
###
pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/plot7.pdf",plot1)
plot7<-plot(log(real_matrix_243$"2015") ~ log(simulation_matrix$simu_x7),main="G7")
dev.off()

# plots one after another to see the changes

plot1<-plot(log(real_matrix_243$"1985") ~ log(simulation_matrix$simu_x1),main="G1")
plot2<-plot(log(real_matrix_243$"1990") ~ log(simulation_matrix$simu_x2),main="G2")
plot3<-plot(log(real_matrix_243$"1995") ~ log(simulation_matrix$simu_x3),main="G3")
plot4<-plot(log(real_matrix_243$"2000") ~ log(simulation_matrix$simu_x4),main="G4")
plot5<-plot(log(real_matrix_243$"2005") ~ log(simulation_matrix$simu_x5),main="G5")
plot6<-plot(log(real_matrix_243$"2010") ~ log(simulation_matrix$simu_x6),main="G6")
plot7<-plot(log(real_matrix_243$"2015") ~ log(simulation_matrix$simu_x7),main="G7")

## Same graphs but for % increase from previous year.
# export real_matrix_243 for Elise
write.csv(real_matrix_243,file="//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/outputs/real_matrix_243.csv")

# initialize empty dataframe
real_matrix_243_increase <- data.frame(matrix(ncol = 9, nrow = 243))
real_matrix_243_increase[,1] <- real_matrix_243[,1] # give species names
col_names <- c("species_name","1982","1985","1990","1995","2000","2005","2010","2015")
colnames(real_matrix_243_increase) <- col_names # give column names

head(real_matrix_243_increase) # Check it has worked
# should encapsulate into a function

for(i in 1:nrow(real_matrix_243_increase))
  {
  for(j in 1:(ncol(real_matrix_243_increase)-2))
  {
    if (real_matrix_243[i,j+1] == 0){
      real_matrix_243_increase[i,j+1] = 0
    }
    else {
    real_matrix_243_increase[i,j+1] = (real_matrix_243[i,j+2]-real_matrix_243[i,j+1])/real_matrix_243[i,j+1]
    }
  }
}

head(real_matrix_243_increase)
# See if the formula has done the right thing
real_matrix_243_increase[1,2] == (real_matrix_243[1,3] - real_matrix_243[1,2])/real_matrix_243[1,2]

real_matrix_243_increase[23,4] == (real_matrix_243[23,5] - real_matrix_243[23,4])/real_matrix_243[23,4]

# Do the same for the simulated matrix

col_names <- c("species_name","1982","1985","1990","1995","2000","2005","2010","2015") 
colnames(simulation_matrix_243) <- col_names # give column names

# Create % increases


# initialize empty dataframe
simulated_matrix_243_increase <- data.frame(matrix(ncol = 9, nrow = 243))
simulated_matrix_243_increase[,1] <- simulation_matrix_243[,1] # give species names
col_names <- c("species_name","1982","1985","1990","1995","2000","2005","2010","2015")
colnames(simulated_matrix_243_increase) <- col_names # give column names

head(real_matrix_243_increase) # Check it has worked
# should encapsulate into a function

for(i in 1:nrow(simulated_matrix_243_increase))
{
  for(j in 1:(ncol(simulated_matrix_243_increase)-2))
  {
    if (simulation_matrix_243[i,j+1] == 0){
      simulated_matrix_243_increase[i,j+1] = 0
    }
    else {
      simulated_matrix_243_increase[i,j+1] = (simulation_matrix_243[i,j+2]-simulation_matrix_243[i,j+1])/simulation_matrix_243[i,j+1]
    }
  }
}


# Obtain slopes and R2 for each generation of real_increase vs. simulated_increase

###
#linear models Porblem!! mismatch between generations in both datasets
###

lm_1985 <- lm(simulated_matrix_243_increase$"1985" ~ real_matrix_243_increase$"1985")
summary(lm_1985)
# slope: 0.197179, std. err:  0.022357, R2: 0.244
###
lm_1990 <- lm(simulated_matrix_243_increase$"1990" ~ real_matrix_243_increase$"1990")
summary(lm_1990)
# slope: 0.238360, std. err: 0.037696, R2: 0.1423
###
lm_1995 <- lm(simulated_matrix_243_increase$"1995" ~ real_matrix_243_increase$"1995")
summary(lm_1995)
# slope: 0.14734, std. err: 0.02155, R2: 0.1625
###
lm_2000 <- lm(simulated_matrix_243_increase$"2000" ~ real_matrix_243_increase$"2000")
summary(lm_2000)
# slope: 0.128436, std. err: 0.022651, R2: 0.1177
###
lm_2005 <- lm(simulated_matrix_243_increase$"2005" ~ real_matrix_243_increase$"2005")
summary(lm_2005)
# slope: 0.10616, std. err: 0.02520, R2: 0.06859
###
lm_2010 <- lm(simulated_matrix_243_increase$"2010" ~ real_matrix_243_increase$"2010")
summary(lm_2010)
# slope: 0.022163, std. err: 0.021908, R2: 0.004228
###
lm_2015 <- lm(simulated_matrix_243_increase$"2015" ~ real_matrix_243_increase$"2015")
summary(lm_2015)
# slope: , std. err: , R2: 


###
#Plots
###


plotA<-plot(log(real_matrix_243_increase$"1985") ~ log(simulated_matrix_243_increase$"1985"),main="G1")
plotB<-plot(log(real_matrix_243_increase$"1990") ~ log(simulated_matrix_243_increase$"1990"),main="G2")
plotC<-plot(log(real_matrix_243_increase$"1995") ~ log(simulated_matrix_243_increase$"1995"),main="G3")
plotD<-plot(log(real_matrix_243_increase$"2000") ~ log(simulated_matrix_243_increase$"2000"),main="G4")
plotE<-plot(log(real_matrix_243_increase$"2005") ~ log(simulated_matrix_243_increase$"2005"),main="G5")
plotF<-plot(log(real_matrix_243_increase$"2010") ~ log(simulated_matrix_243_increase$"2010"),main="G6")
plotG<-plot(log(real_matrix_243_increase$"2015") ~ log(simulated_matrix_243_increase$"2015"),main="G7")






