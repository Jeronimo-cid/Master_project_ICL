#This script reads the frequin_de and reproductive_counts datasets
#from Armand and exports them into excel

require(dplyr)
# setwd("D:/Music&documents/Documentos/UNIVERSIDAD - MSc EEC _ ImpColl/1.COURSE MATERIALS/3.Master Project - Summer Term/Master_Project/data/Provisional_betas_freqs_22_4")
setwd("//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/data/Provisional_betas_freqs_22_4")

getwd()

##Betas
d<-load(file="beta_freqinde.rds") # error due to magic number,
#so load the file from the directory by clicking on it ("reproductive_counts")
#load betas by generating the file from the script "Selection plots_frequency independent", line 92.
#object should be called "beta1" and have 269 rows in 4 columns with the last rows being zeros.
d<-beta1
d1<-d%>%select(beta_freqinde_50)
write.csv(d1,file="D:/Music&documents/Documentos/UNIVERSIDAD - MSc EEC _ ImpColl/1.COURSE MATERIALS/3.Master Project - Summer Term/Master_Project/data/beta1_excel.csv")

##frequencies
#extract starting frequencies column
x0<-as.matrix(reproductives_counts%>%select(-count,-speciesYear)%>%filter(censusyear==1982)%>%select(freq))


write.csv(x0,file="D:/Music&documents/Documentos/UNIVERSIDAD - MSc EEC _ ImpColl/1.COURSE MATERIALS/3.Master Project - Summer Term/Master_Project/data/x0.csv")

##Exploration of x0
str(x0)
range(x0)
hist(x0, breaks = c(0.00:0.44, by=0.001))
which(x0>0.43) # Hybanthus prunifolius, line 113
which(reproductives_counts$freq>0.43) # same species, starts in line 897

# Plotting: 
require(lattice)
plots<-reproductives_counts%>%select(-count,-speciesYear)%>%group_by(species)
xyplot(plots$freq ~ plots$censusyear,
       groups = plots$species,
       main = "Real frequencies",
       xlab = "Census year",
       ylab = "Frequency abundance")

which(reproductives_counts$freq>0.1) # Faramea occidentalis, next most abundant, 661 662 663 664

##Exploration of betas
str(d1)
range(d1) # min = -0.8092461,  max = 0.9637360
d1<-as.matrix(d1)
hist(d1) # strong left skew

# Plotting betas against my s_vec to see that my transformation is linear

s_vec <- (d2$beta_freqinde_50+1)/2

plot<-plot(d1 ~ s_vec)

# Explore selection part of the model to see why it's not a probability vector

boxplot(d1)
boxplot(x0)
range(x0)
range(d1)

G1 <- x0 + d1*x0
G2 <- x0 + s_vec*x0
range(G1)
range(G2)

d1*x0
s_vec*x0

# extract final frequencies column
x8<-as.matrix(reproductives_counts%>%select(-count,-speciesYear)%>%filter(censusyear==2015)%>%select(freq))
write.csv(x8,file="D:/Music&documents/Documentos/UNIVERSIDAD - MSc EEC _ ImpColl/1.COURSE MATERIALS/3.Master Project - Summer Term/Master_Project/data/x8.csv")


plot(x0,betas)