library(fitdistrplus)    # fits distributions using maximum likelihood

x <- c(5,2,1,4,5,1,2)
fit_zip = fitdist(x, 'pois', start = list(lambda=4))

fit_zip

y <- c(3, 1, 1,	4, 11,	1,	3)
fit_y = fitdist(y, 'pois', start = list(lambda=4))

fit_y