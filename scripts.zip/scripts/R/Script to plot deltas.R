

setwd("C:/Users/Jeronimo/OneDrive - Imperial College London/Master_Project/data/")
getwd()
rm(list=ls()) 
####
#install.packages("ggplot2")
require(dplyr)
require(tidyr)
require(stringr)
require(lattice)
require(ggplot2)


deltas_quantiles <- read.csv("C:/Users/Jeronimo/OneDrive - Imperial College London/Master_Project/outputs/iotas_quantiles_report.csv")

#Initialize a vector of colors
col = rep(0, length(deltas_quantiles$x1))
for (i in seq(length(deltas_quantiles$x3))){
  if (deltas_quantiles$x3[i]>0){
    col[i] = 1
  }
  else if (deltas_quantiles$x5[i] < 0){
    col[i] = -1
  }
}

  # deltas_quantiles['x'] = seq(243)
deltas_quantiles['col'] = col


#Plot
deltas_species_plot<- ggplot(data = deltas_quantiles, aes(x = x2, y  = x4, colour = as.factor(col)))+
  geom_point()+
  geom_errorbar(aes(ymin = x3, ymax = x5, colour = as.factor(col)))+
  theme_classic(base_size = 15)+xlab("species_ID")+ylab("difference between final simulated and real frequencies")+
  ggtitle("Test of the simulation for individual species")+
  
  scale_color_manual(values=(c('blue', 'black', 'red')),labels = c("under predict","predict well","overpredict"))+
  theme(legend.title = element_text(color = 'black',
                                    size = 10))+
  labs(colour = "legend")

  scale_colour_discrete(labels = c("under predict","predict well","overpredict"))
  
# export graph

#pdf(file = "//icnas3.cc.ic.ac.uk/jjc3818/Desktop/Master_Project/figures/deltas_species_plot.pdf")

ggsave(
  "iotas_species_plot_report.pdf",
  plot = last_plot(),
  device = "pdf",
  path = "C:/Users/Jeronimo/OneDrive - Imperial College London/Master_Project/figures",
  scale = 1,
  width = NA,
  height = NA,
  units = c("in", "cm", "mm"),
  dpi = 300,
  limitsize = TRUE)


